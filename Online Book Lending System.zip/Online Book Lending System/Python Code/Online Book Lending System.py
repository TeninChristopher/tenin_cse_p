import mysql.connector as s
import datetime


def register():
    name=input("Enter your Name: ")
    email=input("Enter your Email in format(user@example.com): ")
    membership_type=input("Enter your membership(Basic/Premium): ")
    date=datetime.date.today()
    cur.execute('select id from users')
    data=cur.fetchall()
    if data==[]:
        query='insert into users (id, name, email, membership_type, created_at) values ({}, "{}", "{}", "{}", "{}");'.format(1, name, email, membership_type, date)
    else:
        query='insert into users (id, name, email, membership_type, created_at) values ({}, "{}", "{}", "{}", "{}");'.format(data[-1][0]+1, name, email, membership_type, date)
    return query

def bookadd():
    title=input("Enter Book Title: ")
    author=input("Enter Author Name: ")
    isbn=input("Enter isbn Code: ")
    availability=input("Enter Availability(True/False): ")
    date=datetime.date.today()
    cur.execute('select id from books')
    data=cur.fetchall()
    if data==[]:
        query='insert into books (id, title, author, isbn, availability, added_at) values ({}, "{}", "{}", "{}", "{}", "{}");'.format(1, title, author, isbn, availability, date)
    else:
        query='insert into books (id, title, author, isbn, availability, added_at) values ({}, "{}", "{}", "{}", "{}", "{}");'.format(data[-1][0]+1, title, author, isbn, availability, date)
    return query

def borrow():
    borrow_book=int(input("Enter Book Id: "))
    cur.execute('select availability from books where id={};'.format(borrow_book))
    data=cur.fetchone()
    date=datetime.date.today()
    if data[0]=="True":
        cur.execute('update books set availability = "False" where id={};'.format(borrow_book))
        user_id=int(input('Enter your user ID: '))
        cur.execute('select id from transactions')
        data=cur.fetchall()
        if data==[]:
            query='insert into transactions (id, user_id, book_id, borrowed_at) values ({}, {}, {}, "{}");'.format(1, user_id, borrow_book, date)
        else:
            query='insert into transactions (id, user_id, book_id, borrowed_at) values ({}, {}, {}, "{}");'.format(data[-1][0]+1, user_id, borrow_book, date)
        cur.execute(query)
    else:
        print("Book has been borrowed please borrow another one")

def returned():
    returned_book=int(input("Enter Book Id: "))
    cur.execute('select availability from books where id={};'.format(returned_book))
    data=cur.fetchone()
    date=datetime.date.today()
    if data[0]=="False":
        cur.execute('update books set availability = "True" where id={};'.format(returned_book))
        cur.execute('update transactions set returned_at = "{}" where book_id={};'.format(date, returned_book))
    else:
        print("book has not been borrowed to return")

def transactions():
    cur.execute('select * from transactions;')
    data=cur.fetchall()
    print("Id | UserID | BookID | BorrowedAt | ReturnedAt")
    if data==[]:
        print(None)
    else:
        for i in data:
            print(i[0]," "+"|"+" "*2,i[1]," "*3+"|"+" "*3,i[2],"  |",i[3],"|",i[4])

rcount=0
con1=s.connect(host="localhost",user="root",password="password@123",database="obs")
cur=con1.cursor()
while True:
    print('MENU')
    print('1. Create Account')
    print('2. Add Book')
    print('3. Borrow Book')
    print('4. Return Book')
    print('5. Show Transactions')
    print('6. Exit')
    num=int(input("Enter your choice: "))
    match num:
        case 1:
            cur.execute(register())
        case 2:
            cur.execute(bookadd())
        case 3:
            borrow()
        case 4:
            returned()
        case 5:
            transactions()
        case 6:
            print("Ending Program")
            con1.close()
            break
    con1.commit()


